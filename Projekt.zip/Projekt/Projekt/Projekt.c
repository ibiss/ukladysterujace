//Dariusz Michalski, Agnieszka Sloma, Mateusz Mikita
#define F_CPU 16000000UL // 16 MHz
#include "HD44780.h"
#include <avr/io.h>
#include <avr/interrupt.h>
#include <stdio.h>
#include <util/delay.h>
#include "cooperative_scheduler.h"
//#define NULL ((char *)0)
uint8_t CYFRA[] = {0xC0, 0xF9, 0xA4, 0xB0, 0x99, 0x92, 0x82, 0xF8, 0x80, 0x90};
uint32_t seconds = 0;
uint8_t klawisz = 1;
ISR(TIMER0_COMP_vect)
{
	//change_segment();
	schedule();
}
uint8_t liczba(uint8_t segment)
{
	switch (segment)
	{
		case 0:
			return seconds % 10;
			break;
		case 1:
			return (seconds / 10) % 10;
			break;
		case 2:
			return (seconds / 100) % 10;
			break;
		case 3:
			return (seconds / 1000) % 10;
			break;
	}
}
uint8_t liczba2(uint8_t segment)
{
	switch (segment)
	{
		case 0:
			return klawisz % 10;
			break;
		case 1:
			return (klawisz / 10) % 10;
			break;
		case 2:
			return (klawisz / 100) % 10;
			break;
		case 3:
			return (klawisz / 1000) % 10;
			break;
	}
}

void change_segment()
{
	static uint8_t segment = 0;
	PORTA = CYFRA[liczba2(segment)];
	PORTB = PORTB & 0xF0 | (~(1 << segment)) & 0x0f;
	segment = (segment +1) % 4;
}

void timer0_init(void)
{
	TCCR0 |= (1 << WGM01);
	TIMSK |= (1 << OCIE0);
	OCR0 = 250;
	sei();
	TCCR0 |= (1 << CS00) | (1 << CS01);
}
#define TRYB_WYSWIETLANIA 0
#define TRYB_ZMIANY_CZASU 1
#define TRYB_USTAWIANIA_ALARMU 3
#define WYSWIETL_ALARM 4
#define TRYB_GM 0
#define TRYB_MS 1
#define WYSWIETLAJ 0
#define GODZINA 0
#define MINUTA 1
#define SEKUNDA 2
uint8_t alarm = 0
uint8_t idx_alarmu = 0;
uint8_t alarmy[8][3] = {
	{ 0, 0 ,0},
	{ 0, 0 ,0},
	{ 0, 0 ,0},
	{ 0, 0 ,0},
	{ 0, 0 ,0},
	{ 0, 0 ,0},
	{ 0, 0 ,0},
	{ 0, 0 ,0},
	};

uint8_t tryb_wyswietlania = 0;
uint8_t tryb = 0;
uint8_t ustawiany = 0;
uint8_t sekundy = 0;
uint8_t minuty = 0;
uint8_t godziny = 0;

void ObsluzKlawisz(uint8_t k)
{
	//uint8_t Liczby[] = {0x77, 0xB7, 0xD7, 0xE7, 0x7B, 0xBB, 0xDB, 0xEB, 0x7D, 0xBD, 0xDD, 0xED, 0x7E, 0xBE, 0xDE};//, 0xEE};
	uint8_t Liczby[] = {0xEE,0xDE, 0xBE, 0x7E, 0xED,0xED,0xDD,0xBD,0x7D,0xEB,0xDB,0xBB,0x7B,0xE7,0xD7,0xB7,0x77 };//poprawna wartosc
	uint8_t i = 0;
	for (;i <16;i++)
		if(Liczby[i] == k)
			break;
	klawisz = i;
	switch(i):
		case 0:
			if(tryb_wyswietlania)
				tryb_wyswietlania = TRYB_MS;
			else
				tryb_wyswietlania = TRYB_GM;
			break;
		case 1:
			if(tryb == TRYB_WYSWIETLANIA)
			{
				tryb = TRYB_ZMIANY_CZASU;
				ustawiany = GODZINA;
			}
			else if(tryb == TRYB_USTAWIANIA_ALARMU)
				break;
			else
			{
				tryb = TRYB_WYSWIETLANIA;
			}
			break;
		case 2:
			if(tryb == TRYB_ZMIANY_CZASU)
			{
				ustawiany = (ustawiany+1) % 3;
			}
			break;
		case 3:
			if(tryb == TRYB_ZMIANY_CZASU)
			{
				switch(ustawiany):
					case 0:
						godziny = (godziny + 1) % 24;
						break;
					case 1:
						minuty = (minuty + 1) % 60;
						break;
					case 2:
						sekundy = (sekundy + 1) % 60;
						break;
			}
			if(tryb == TRYB_USTAWIANIA_ALARMU)
			{
				alarmy[idx_alarmu][ustawiany] = (alarmy[idx_alarmu][ustawiany] + 1) % 60;
			}
			break;
		case 4:
			if(tryb == TRYB_ZMIANY_CZASU)
			{
				switch(ustawiany):
					case 0:
						if(godziny - 1 == -1)
							godziny = 23;
						else
							godziny--;
						break;
					case 1:
						if(minuty - 1 == -1)
							minuty = 59;
						else
							minuty--;
						break;
					case 2:
						if(sekundy - 1 == -1)
							sekundy = 59;
						else
							sekundy--;
						break;
			}
			if(tryb == TRYB_USTAWIANIA_ALARMU)
			{
				switch(ustawiany):
					case 0:
						if(alarmy[idx_alarmu][0] - 1 == -1)
							alarmy[idx_alarmu][0] = 23;
						else
							alarmy[idx_alarmu][0]--;
						break;
					case 1:
						if(alarmy[idx_alarmu][1] - 1 == -1)
							alarmy[idx_alarmu][1] = 59;
						else
							alarmy[idx_alarmu][1]--;
						break;
					case 2:
						if(alarmy[idx_alarmu][2] - 1 == -1)
							alarmy[idx_alarmu][2] = 59;
						else
							alarmy[idx_alarmu][2]--;
						break;
			}
			break;
		case 5:
			if(tryb != TRYB_USTAWIANIA_ALARMU)
			{
				tryb = TRYB_USTAWIANIA_ALARMU;
				idx_alarmu = 0;
			}
			else
				tryb = TRYB_WYSWIETLANIA;
			break;
		case 6:
			if(tryb == TRYB_USTAWIANIA_ALARMU)
			{
				idx_alarmu = (idx_alarmu + 1) % 7;
			}
			break;
			
}
void Alarm()
{
	for(int i =0; i < 8; i++)
	{
		if(alarmy[i][0] == godziny && alarmy[i][1] == minuty)
		{
			alarm = WYSWIETL_ALARM;
			idx_alarm = i;
		}
		else if(alarmy[i][0] == godziny && alarmy[i][1] == minuty+1)
			alarm = 0;
	}
}
void ObslugaKlawiatury(void * params)
{
	PORTD = 0x00;
	DDRD = 0xF0;
	PORTD = 0x0F;
	for (int i=0;i<100;i++);
	uint8_t key = PIND;
	PORTD = 0x00;
	DDRD = 0x0F;
	PORTD = 0xF0;
	for (int i=0;i<100;i++);
	key |= PIND;
	DDRC |= 0xFF;
	PORTC = key;
	ObsluzKlawisz(key);
}


void AddSecond()
{
	sekundy++;
}
void Czas()
{
	if (sekundy == 60)
	{
		minuty++;
		sekundy = 0;
	}
	if(minuty == 60)
	{
		godziny++;
		minuty = 0;
	}
	if(godziny==24)
	{
		godziny = 0;
	}
}

char* linia1 = "00:00";
char* linia2 = "Alarma 1";


void StworzLinie1(uint8_t tryb, uint8_t ustaw)
{
	LCD_GoTo(0,0);
	char *ss;
	char *sm;
	char *sg;
	char* s = itoa(sekundy, ss, 10);
	if(sekundy <=10)
		s = strcat("0",s);
	char* m = itoa(minuty, sm, 10);
	if(minuty <= 10)
		m = strcat("0",m);
	char* g = itoa(godziny, sg, 10);
	if(godziny <= 10)
		g = strcat("0",g);
	char* d = ":";
	if(ustawiany == SEKUNDA)
		s = "  ";
	else if(ustawiany == MINUTA)
		m = "  ";
	else if(ustawiany == GODZINA)
		g = "  ";
	if(tryb == TRYB_GM)
	{
		linia1[0] = g[0];
		linia1[1] = g[1];
		linia1[3] = m[0];
		linia1[4] = m[1];
	}
	else
	{
		linia1[0] = m[0];
		linia1[1] = m[1];
		linia1[3] = s[0];
		linia1[4] = s[1];
	}
}
void UstawLinie2()
{
	char *str;
	char *i = itoa(idx_alarm, str, 10);
	if(alarm)
		LCD_GoTo(0,1);
		LCD_WriteText(strcat("Alarm ", i);
}

void WyswietlNaLCD()
{
	char *str;
	char *str2;
	LCD_Clear();
	sekundy=1;
	char* s = itoa(sekundy, str, 10);
	char* m = itoa(minuty, str2, 10);
	/*char* g = itoa(godziny, str, 10);
	char* napis = strcat(strcat(strcat(g,":"),strcat(m,":")),s);
	char *n = strcat(s,g);*/
	LCD_WriteText(strcat(s,m));
	
}
int main(int argc, char * argv[])
{
	DDRA |= 0xFF;
	DDRB |= 0xFF;
	timer0_init();
	LCD_Initalize();
	LCD_Clear();
	LCD_GoTo(0,0);
	//LCD_WriteText("A");
	//AddTask(0, 1, ObslugaKlawiatury, NULL);
	//AddTask(0, 1, AddSecond, NULL);
	AddTask(0, 100, WyswietlLCD, NULL);
	execute();
}
//
//#define UBRR 25
//void USART_Init( void )
//{
///* Set baud rate */
//UBRRH = (unsigned char)(UBRR>>8);
//UBRRL = (unsigned char)UBRR;
///* Enable receiver and transmitter */
//UCSRB = (1<<RXEN)|(1<<TXEN) | (1<<UDRIE);
///* Set frame format: 8data, 2stop bit */
//UCSRC = (1<<URSEL)|(1<<USBS)|(3<<UCSZ0);
//}
//void USART_Transmit( uint8_t data )
//{
///* Wait for empty transmit buffer */
//while ( !( UCSRA & (1<<UDRE)) )
//;
///* Put data into buffer, sends the data */
//UDR = data;
//}
//
//uint8_t USART_Receive( void )
//{
///* Wait for data to be received */
//while ( !(UCSRA & (1<<RXC)) )
//;
///* Get and return received data from buffer */
//return UDR;
//}
//uint8_t len = 10;
//uint8_t znak;
//uint8_t ZDANIE[10];
//uint8_t i = 0;
//ISR(USART_RXC_vect)
//{
//DDRC = 0xFF;
//znak = UDR;
//PORTC = 0xFF;
//ZDANIE[i++] = znak;
//}
//int main(int argc, char * argv[])
//{
//sei();
//DDRC = 0xFF;
//uint8_t znak = 0xFF;
//USART_Init();
//while(1)
//{
////znak = USART_Receive();
////PORTC = znak;
//if(i==8)
//{
//for(int j = 0; j < len;j++)
//USART_Transmit(ZDANIE[j]);
//i = 0;
//}
////USART_Transmit(znak);
//}
//}
//
