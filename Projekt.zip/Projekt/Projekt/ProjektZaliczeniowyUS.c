/* Projekt zaliczeniowy
 * Układy Sterujšce
 * Rok Akademicki 2012/2013
 * II UJ
 * Paweł Podubiński
 * Bartłomiej Kroczek
 */

#define F_CPU 16000000UL
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>

/* Stałe i rozkazy wykorzystywane przez wywietlacz LCD*/ 
#define DANE 1
#define POLECENIE 0
#define E (1<<PINA1)
#define RS (1<<PINA0)
#define CZYSC_WYSWIETLACZ 1 //1(kod rozkazu)
#define KURSOR_W_LEWO 16 //16(kod rozkazu) + 0(kursor) + 0(w lewo)
#define KURSOR_W_PRAWO 20 //16(kod rozkazu) + 0(kursor) + 4(w prawo) 
#define KURSOR_NA_PIERWSZA_LINIE 128 //128(kod rozkazu) + 0(adres komórki)
#define KURSOR_NA_DRUGA_LINIE 169 //128(kod rozkazu) + 41(adres komórki)
#define POWROT_KARETKI 2 //2(kod rozkazu)
#define WYSWIETLACZ_W_LEWO 24 //16(kod rozkazu) + 8(wywietlacz) + 0(w lewo)
#define WYSWIETLACZ_W_PRAWO 28 //16(kod rozkazu) + 8(wywietlacz) + 4(w prawo)
#define TRYB_WYSWIETLACZA 40 //32(kod rozkazu) + 0(4 bity) + 8(2 linie) + 0(czcionka 5x8) 
#define TRYB_USTAWIEN 8 //(kod rozkazu) 
#define KONTROLA_WYSWIETLACZA 15 //8(kod rozkazu) + 4(wywietlacz wł.) + 2(kursor wł.) + 1(mruganie wł.) 
#define TRYB_WEJSCIA 6 // 4(kod rozkazu) + 2(inkrementacja) + 0(ledzenie wył.)

/* Stałe wykorzystywane przez interface USART
 * wartoć dzielnika przy 16 MHz dla prędkoci 9600 B/s 
 */
#define DZIELNIK 103 

/* Stałe ustalajšce rozmiar rzutowanych liter */ 
#define BEZZMIAN 0 
#define MALELITERY 1
#define DUZELITERY 2

/* Zmienne globalne */
int wyswietlana; // Wartoć zmiennej wywietlana na wywietlaczu 7-segmentowym
int wybranyPrzycisk; // Zapamiętuje wybrany na klawiaturze przycisk
int rozmiarLiter; // Zapamiętuje wielkoć liter do wywietlenia na LCD 

/* Kod obsługujšcy wywietlacz LCD hd44780
 * Tryb 4 bitowy  rozmiar 2 x 40 znaków 
 * Podpięty do Portu A zgodnie z opisem:
 * PA0 = RS
 * PA1 = E
 * PA4 = D4
 * PA5 = D5
 * PA6 = D6
 * PA7 = D7 
 */

/* Funkcja wysyła 4 starsze bity zmiennej val do urzšdzenia */
void HiBit(uint8_t val){

	PORTA |=E;
	PORTA = (PORTA&0x0F) | (val&0xF0);
	PORTA &= ~E;
}

/* Funkcja wysyła 4 młodsze bity zmiennej val do urzšdzenia */
void LowBit(uint8_t val){

	PORTA |=E;
	val = val << 4;
	PORTA = (PORTA&0x0F) | (val&0xF0);
	PORTA &= ~E;
}

/* Funkcja korzystajšc z HiBit i LowBit wysyła cała 8 bitowš wartoć do urzšdzenia 
 * Zmienna rodzajDanych przyjmuje stałe POLECENIE lub DANE, 
 * w zależnoci czy wysyłamy danę czy instrukcje wywietlacza 
 */
void Send(uint8_t val, int rodzajDanych){
	
	if(rodzajDanych == POLECENIE)
		PORTA &= ~RS; // RS = 0
	else if(rodzajDanych == DANE)
		PORTA |= RS; // RS = 1
		
	HiBit(val);
	LowBit(val);
}

/* Metoda inicjalizujšca Wywiatlacz LCD, zgodnie z dokumentacjš */
void LCDInit(){
	
	DDRA |= 0xf3; //Ustawiamy potrzebne dla LCD porty, pozostałe zostawiamy w spokoju
	
	_delay_ms(15);
	for(int i = 0; i <3; i++){
		LowBit(0x3);
		_delay_ms(5);
	}	
	LowBit(POWROT_KARETKI);
	_delay_ms(2);
	Send(TRYB_WYSWIETLACZA,POLECENIE);
	_delay_ms(2);
	Send(TRYB_USTAWIEN,POLECENIE);
	_delay_ms(2);
	Send(CZYSC_WYSWIETLACZ,POLECENIE);
	_delay_ms(2);
	Send(TRYB_WEJSCIA,POLECENIE);
	_delay_ms(2);
	Send(KONTROLA_WYSWIETLACZA,POLECENIE);
	_delay_ms(2);
	Send(KURSOR_NA_PIERWSZA_LINIE,POLECENIE);
	_delay_ms(130);
}

/* Metoda wypisujšca na wywietlacz przekazany jej łańcuch znakowy */
void Write_Text(char * napis){
	
	int i = 0;
	while(napis[i] != 0){
		Send(napis[i], DANE);
		_delay_ms(1);
		i++;
	}
}

/* Koniec Funkcji obsługi wywietlacza LCD  */

/* Enkoder kodu BCD8421 na kod 7 segmentowy dla cyfr 0-9 */
int BCD_to_7segment(int wejscie){
	
	switch(wejscie){
		case 1:
			return 0b11111001;
		case 2:
			return 0b10100100;
		case 3:
			return 0b10110000 ;
		case 4:
			return 0b10011001;
		case 5:
			return 0b10010010;
		case 6:
			return 0b10000010;
		case 7:
			return 0b11111000;
		case 8:
			return 0b10000000;
		case 9:
			return 0b10010000;
		case 0:
			return 0b11000000;
		default:
			return 0b00000000;
	}
}

/* Metoda inicjalizujšca interface USART */
void USART_init(void){
	
	//do UBRRH i UBRRL wstawiamy wartoć dzielnika, do RH 8 starszych a do RL 8 młodszych bitów
	UBRRH = (unsigned char)(DZIELNIK >> 8); //8 starszych bitów przechodzi na młodsze
	UBRRL = (unsigned char)DZIELNIK;
	
	UCSRB = (1<<RXEN)|(1<<TXEN)|(1<<RXCIE); //odbiornik wł. transmiter wł. przerwanie odbiornika wł.
	UCSRC = (1<<URSEL)|(1<<UCSZ1)|(1<<UCSZ0);
	/* URSEL = 1 => pracujemy z UCSRC a nie z UBRRH
	 * UMSEL = 0 => transmisja asynchroniczna
	 * UPM1 = UPM0 = 0 => brak kontroli parzystoci
	 * USBS = 0 => 1 bit stopu 
	 * UCSZ1 = UCSZ0 = 1, UCSZ2 = 0 => Ramka 8 bitów */
}

/* Metoda inicjalizujšca wbudowany 8bitowy zegar/licznik0 
 * 16000000 Hz / (64 * 250) = 1000 Hz
 * 16000000 - częstotliwoć mikrokontrolera
 * 64 - ustawiony dzielnik częstotliwoci
 * 250 - wartoć do której odlicza licznik
 * 1000 Hz  - częstotliwoć zgłaszania przerwań przez zegar
 * dokładnie 1000 przerwań na sekunde 
 */
void Clock_init(void){
	
	OCR0 = 250; //wartoć do której odlicza licznik
	TCCR0 |= (1<<WGM01); // Clear Timer on Compare Match (CTC) mode
	TCCR0 |= (1<<CS01) | (1<<CS00); // dzielnik częstotliwoci zegara /64
	TIMSK |= (1<<OCIE0); // uruchomienie licznika
}

/* Metoda ustawiajšce stany poczštkowe portów dla wywietlacza 7 segmentowego
 * przy założeniu że dane wystawiane sš na port C zgodnie ze schematem:
 * PC0 = a
 * PC1 = b
 * ...
 * a sterowanie wywietlaczem jest na 4 starszych bitach portu D
 */
void Display_init(void){
	DDRC = 0xff; //ustawienie portu jako wyjsciowy
	PORTC = 0x00; //wstepne ustawienie wartosci na wyjsciu
	DDRD |= 0xf0; //ustawienie połowy portu jako wyjsciowy
}

/* Ustawienie portu B dla klawiatury w trybie płynšcego 0 */
void Keyboard_init(){
	DDRB = 0x0f; //wejscie/wyjscie dla klawiatury
	PORTB = 0xff;
}

/* Metoda obsługujšca klawiaturę 16 klawiszowš metodš pływajšcego 0 
 * numer wybranego przycisku wpisywany jest do zmiennej wybranyPrzycisk
 */
void klawiatura(void){
	
	static int licznik = 0;
	//Zero w kolumnie w zależnoci od wartoci licznika (w przedziale <0,3> )
	switch(licznik){
		case 0:
			PORTB = 0b11111110;
			break;
		case 1:
			PORTB = 0b11111101;
			break;
		case 2:
			PORTB = 0b11111011;
			break;
		case 3:
			PORTB = 0b11110111;
			break;
	}
	
	uint8_t wartosc = ~PINB; //wartoć = stan na porcie 
	wartosc &= 0xf0; //ignorujemy bity pływajšcego zera 
	
	int wiersz = 0; // wiersz = numer przycinietego klawisza w wierszu 
	
	if(wartosc == 0x10)
		wiersz = 0;
	else if(wartosc == 0x20)
		wiersz = 1;
	else if(wartosc == 0x40)
		wiersz = 2;
	else if(wartosc == 0x80)
		wiersz = 3;
	
	if(wartosc != 0x00){ //klawisz został przyciniety
		wybranyPrzycisk = wiersz + 4*licznik + 1;	
		Button_service(); //obsługa wybranego przycisku
	}		
	_delay_ms(10);
	
	//zero płynie po wierszach zgodnie z wartociš licznika 
	if(licznik != 4)
		licznik++;
	else licznik = 0;
}

/* Metoda reagujšca na wybrany przycisk
 * dodatkowo zapala lub gasi dwie diody sygnaluzujšce rozmiar liter
 */
void Button_service(void){
	
	switch(wybranyPrzycisk){
		case 1:
			Send(CZYSC_WYSWIETLACZ,POLECENIE);
			wybranyPrzycisk = 0;
			break;
		case 2:
			Send(KURSOR_W_LEWO,POLECENIE);
			_delay_ms(70);
			wybranyPrzycisk = 0;
			break;
		case 3:
			Send(KURSOR_NA_DRUGA_LINIE,POLECENIE);
			wybranyPrzycisk = 0;
			_delay_ms(70);
			break;
		case 4:
			Send(KURSOR_W_PRAWO,POLECENIE);
			_delay_ms(70);
			wybranyPrzycisk = 0;
			break;
		case 5:
			rozmiarLiter = BEZZMIAN;
			PORTA &= 0b11110011;  //gasimy diody
			break;
		case 6:
			rozmiarLiter = DUZELITERY;
			PORTA |= 0b00001000; //jednš zapalamy
			PORTA &= 0b11111011; // drugš gasimy
			break;
		case 7:
			Send(KURSOR_NA_PIERWSZA_LINIE,POLECENIE);
			wybranyPrzycisk = 0;
			_delay_ms(70);
			break;
		case 8:
			rozmiarLiter = MALELITERY;
			PORTA |= 0b00000100; //jednš zapalamy
			PORTA &= 0b11110111; //drugš gasimy
			break;
		case 9:
			Send(POWROT_KARETKI,POLECENIE);
			_delay_ms(2);
			wybranyPrzycisk = 0;
			break;
		case 10: //przycisk działa jak backspace 
			Send(KURSOR_W_LEWO,POLECENIE);
			_delay_ms(1);
			Send(32,DANE); //wpisujemy spacje
			_delay_ms(1);
			Send(KURSOR_W_LEWO,POLECENIE);
			wybranyPrzycisk = 0;
			_delay_ms(50);
			break;
		case 11:
			Send(WYSWIETLACZ_W_LEWO,POLECENIE);
			_delay_ms(1);
			wybranyPrzycisk = 0;
			break;
		case 12:
			Send(WYSWIETLACZ_W_PRAWO,POLECENIE);
			_delay_ms(1);
			wybranyPrzycisk = 0;
			break;
	}
}

int main(void)
{	
	Keyboard_init();
	USART_init();
	Clock_init();
	Display_init();
	LCDInit();
	sei(); // właczenie obsługi przerwań

	while(1){
		klawiatura();
	}
}

/* Funkcja obsługi przerwania zegarowego polegajšcej na wyswietlaniu wartoci 
 * znajdujšcej się w globalnej zmiennej "wyswietlana" na wywietlaczu 7-segmentowym
 */
ISR(TIMER0_COMP_vect){
	
	cli(); //blokujemy inne przerwania
	static int numerWyswietlacza = 0; // zmienna przechowuję numer wywiatlacza na którym wypisujemy wartosc
	
	if(numerWyswietlacza == 3) //zmieniam wyswietlacz do wypisywania
		numerWyswietlacza = 0;
	else numerWyswietlacza++;

	switch(numerWyswietlacza){ //switch obsługujšcy po koleji wywietlacze
		case 0:
			PORTC = BCD_to_7segment((int)wyswietlana % 10); // wyłuskanie cyfry na odpowiedniej pozycji
			PORTD &= ~(0b00010000); // zapalenie wyswietlacza
			PORTD |= 0b11100000; //ingerujemy tylko w wartoci na Pinach wywietlacza
			break;
		case 1:
			PORTC = BCD_to_7segment((int)(wyswietlana/10) % 10);
			PORTD &= ~(0b00100000);
			PORTD |= 0b11010000;
			break;
		case 2:
			PORTC = BCD_to_7segment((int)(wyswietlana/100) % 10);
			PORTD &= ~(0b01000000);
			PORTD |= 0b10110000;
			break;
		case 3:
			PORTC = BCD_to_7segment((int)(wyswietlana/1000) % 10);
			PORTD &= ~(0b10000000);
			PORTD |= 0b01110000;
			break;
	}
	sei(); //uruchamiamy inne przerwania 
}
/* Przerwanie odbioru danych przez USART */
ISR(USART_RXC_vect){
	
	wyswietlana = UDR;	//przypisanie wartosci z klawiatury do zmiennej
	
	//zmiana rozmiaru liter w zależnoci do wartoci zmiennej globalnej
	if(rozmiarLiter == DUZELITERY)
		wyswietlana = toupper(wyswietlana);
	else if(rozmiarLiter == MALELITERY)
		wyswietlana = tolower(wyswietlana);
	
	Send(wyswietlana,DANE); //wysłanie znaku na wyswietlacz LCD
	UDR = wyswietlana; //transmisja zwrotna do komputera (juz po rzutowaniu!)

}	
